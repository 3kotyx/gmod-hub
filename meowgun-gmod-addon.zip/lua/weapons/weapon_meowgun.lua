/*---------------------------------
Created with buu342s Swep Creator
---------------------------------*/

SWEP.PrintName = "Cat Meower 3000 (a.k.a meowgun!)"
    
SWEP.Author = "3kotyX"
SWEP.Contact = "3kotyx@gmail.com"
SWEP.Purpose = "Become a cat!"
SWEP.Instructions = "Left click to meow, right click to hiss"

SWEP.Category = "3kotyX's SWEPs"

SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 100
SWEP.ViewModel = "" 
SWEP.WorldModel = ""
SWEP.ViewModelFlip = false

SWEP.AutoSwitchTo = true
SWEP.AutoSwitchFrom = false

SWEP.Slot = 1
SWEP.SlotPos = 1
 
SWEP.UseHands = true

SWEP.HoldType = "Pistol" 

SWEP.FiresUnderwater = false

SWEP.DrawCrosshair = true

SWEP.DrawAmmo = true

SWEP.ReloadSound = ""

SWEP.Base = "weapon_base"

SWEP.Primary.Sound = Sound("meowgun/meow.wav")
SWEP.Secondary.Sound = Sound("meowgun/hiss.wav")


SWEP.Primary.Damage = -1
SWEP.Primary.TakeAmmo = -1
SWEP.Primary.ClipSize = 30 
SWEP.Primary.Ammo = "RPG_Round"
SWEP.Primary.DefaultClip = 300
SWEP.Primary.Spread = 0.1
SWEP.Primary.NumberofShots = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Recoil = 0.5
SWEP.Primary.Delay = 0.07
SWEP.Primary.Force = -1


SWEP.Secondary.Damage = -1
SWEP.Secondary.TakeAmmo = 0
SWEP.Secondary.Spread = 0.6
SWEP.Secondary.NumberofShots = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Recoil = 5
SWEP.Secondary.Delay = 0.2
SWEP.Secondary.Force = 0


SWEP.CSMuzzleFlashes = false

function SWEP:Initialize()
util.PrecacheSound(self.Primary.Sound) 
util.PrecacheSound(self.Secondary.Sound) 
util.PrecacheSound(self.ReloadSound) 
        self:SetWeaponHoldType( self.HoldType )
end 

function SWEP:PrimaryAttack()
 
self:EmitSound(Sound(self.Primary.Sound)) 

end 

function SWEP:SecondaryAttack()

self:EmitSound(Sound(self.Secondary.Sound)) 


end

function SWEP:Reload()
self:EmitSound(Sound(self.ReloadSound)) 
        self.Weapon:DefaultReload( ACT_VM_RELOAD );
end

